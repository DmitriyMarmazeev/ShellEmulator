import zipfile
import csv
import sys


class ShellEmulator:
    def __init__(self, config_path):
        self.config = self.load_config(config_path)
        self.hostname = self.config['hostname']
        self.zip_path = self.config['zip_file']
        self.current_dir = "/"  # Начальная директория для пользователя
        self.root_dir = None  # Имя корневой папки архива
        self.virtual_files = self.load_zip()

    def load_config(self, config_path):
        """Загрузка конфигурации из CSV."""
        with open(config_path, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)
        return {
            'hostname': rows[0][0],
            'zip_file': rows[0][1],
        }

    def load_zip(self):
        """Загрузка содержимого zip-файла."""
        virtual_files = {}
        with zipfile.ZipFile(self.zip_path, 'r') as zip_file:
            for name in zip_file.namelist():
                normalized_name = "/" + name.rstrip('/')
                if name.endswith('/'):
                    virtual_files[normalized_name] = None
                else:
                    virtual_files[normalized_name] = zip_file.getinfo(name)

            # Определяем корневую директорию архива
            root_dirs = {name.split('/')[0] for name in zip_file.namelist() if '/' in name}
            if len(root_dirs) == 1:
                self.root_dir = f"/{list(root_dirs)[0]}"
            else:
                raise ValueError("Архив должен содержать только одну корневую папку.")

        return virtual_files

    def map_to_real_path(self, path):
        """Добавляет root_dir к указанному пути."""
        if path == "/":
            return self.root_dir
        return self.root_dir + path

    def execute_command(self, command):
        """Выполнение команды."""
        if command.startswith("cd"):
            self.change_directory(command.split(" ")[1] if len(command.split(" ")) > 1 else "/")
        elif command.startswith("ls"):
            self.list_directory(command.split(" ")[1] if len(command.split(" ")) > 1 else "")
        elif command == "exit":
            self.exit_shell()
        else:
            print(f"{command}: command not found")

    def change_directory(self, path):
        """Команда cd: смена директории."""

        if path == "/":
            # Переход в корень
            self.current_dir = "/"
            return
        elif path == "..":
            # Переход на уровень вверх
            if self.current_dir != "/":
                self.current_dir = '/'.join(self.current_dir.rstrip('/').split('/')[:-1])
                if not self.current_dir.startswith("/"):
                    self.current_dir = "/" + self.current_dir
            if not self.current_dir.endswith("/"):
                self.current_dir += "/"
            return
        elif not path.startswith("/"):
            # Если путь относительный, создаём полный пользовательский путь
            path = self.current_dir.rstrip('/') + '/' + path

        # Проверяем, существует ли директория в архиве
        real_path = self.map_to_real_path(path)
        if real_path in self.virtual_files and self.virtual_files[real_path] is None:
            # Переход в указанную директорию
            self.current_dir = path.rstrip('/') + "/"
        else:
            print(f"cd: {path}: No such file or directory")

    def list_directory(self, path=""):
        """Команда ls: отображение содержимого директории."""
        # Определяем реальный путь: либо переданный, либо текущий
        user_path = self.current_dir + path if path else self.current_dir
        real_path = self.map_to_real_path(user_path).rstrip('/')

        # Проверяем, существует ли директория
        if real_path not in self.virtual_files or (
                real_path in self.virtual_files and self.virtual_files[real_path] is not None):
            print(f"ls: {path}: No such file or directory")
            return

        # Содержимое директории
        dir_path = real_path + "/"
        dir_content = [
            name[len(dir_path):].split('/')[0]
            for name in self.virtual_files
            if name.startswith(dir_path) and name != dir_path
        ]

        # Убираем дубликаты и сортируем
        dir_content = sorted(set(dir_content))

        # Выводим содержимое директории
        print("\n".join(dir_content))

    def exit_shell(self):
        """Команда exit: выход из эмулятора."""
        print("Exiting shell...")
        sys.exit()

    def run(self):
        """Запуск эмулятора."""
        while True:
            command = input(f"{self.hostname}:{self.current_dir if self.current_dir == '/' else self.current_dir[:-1]}$ ")
            self.execute_command(command)


if __name__ == "__main__":
    emulator = ShellEmulator("config.csv")
    emulator.run()